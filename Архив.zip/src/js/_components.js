import "./components/sliders.js";
import "./components/tabs.js";
import "./components/settings.js";
